customers = []
#Products list for next part of project
products = []


menu = 0
while menu != 2:
    print('1. Add a customer')
    print('2. Exit')

    menu_str = input('Choose an option')
    menu = int(menu_str)

    if menu == 1:
        name = input('Add customers name')
        customers.append(name)
        print('Customer added')


